"""Fit scalar mean/std on train/good BRAIN pixels only. Run from repo root:  python scripts/fit_norm_stats.py
Value fitted = (idx - corner_bg)/255 over idx > corner_bg. Valid/test images are never opened.
Writes data/processed/norm_stats.json (used by code) and results/day3/norm_stats.json (tracked evidence).
"""
import csv
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from brainsentinel.data.checks import list_images, load_config, split_dir  # noqa: E402
from brainsentinel.data.palette import train_palette  # noqa: E402
from brainsentinel.data.preprocessing import (  # noqa: E402
    content_hash, file_list_sha256, load_index_image, load_pp_config, resolve_cfg, sha256_file)


def _git(*a):
    try:
        return subprocess.run(["git", *a], cwd=REPO, capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        return None


def main() -> int:
    cfg = resolve_cfg(load_config(REPO / "configs" / "data.yaml"))
    pp = load_pp_config()
    train_dir = split_dir(cfg, "train/good", "img")
    files = list_images(cfg, "train/good")
    exp = cfg["splits"]["train/good"]["expected_n"]
    if len(files) != exp or not all(p.parent == train_dir for p in files):
        sys.exit(f"ABORT: expected {exp} files all under {train_dir}, got {len(files)}")
    pal = train_palette(cfg)  # reads train/good only (palette.train_palette)

    index_path = REPO / pp["index_csv"]
    idx_sha = {}
    if index_path.exists():
        with index_path.open(newline="") as f:
            idx_sha = {r["file"]: r["sha256"] for r in csv.DictReader(f) if r["split"] == "train" and r.get("sha256")}

    s = ss = 0.0
    n = 0
    hashes = {}
    for p in files:
        idx, brain, _ = load_index_image(p, pal, pp["input"]["size"])
        v = idx[brain].astype(np.float64) / 255.0
        s += float(v.sum())
        ss += float((v * v).sum())
        n += int(v.size)
        hashes[p.name] = sha256_file(p)
    mean = s / n
    std = max(ss / n - mean * mean, 0.0) ** 0.5
    matches = sum(1 for k, h in hashes.items() if idx_sha.get(k) == h)

    out = {"fitted_on": "train/good", "only_train_good_read": True, "n_images": len(files),
           "n_files_read": len(files), "n_pixels": n,
           "pixel_set": "brain (idx > corner_bg), offset removed, value = idx/255",
           "file_list_sha256": file_list_sha256(files), "file_content_sha256": content_hash(hashes),
           "index_csv_sha256_matches": f"{matches}/{len(files)}" if idx_sha else None,
           "mean": mean, "std": std, "git_commit": _git("rev-parse", "HEAD")}
    text = json.dumps(out, indent=2) + "\n"
    for path in (REPO / pp["normalize"]["train_stats_path"], REPO / "results" / "day3" / "norm_stats.json"):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
