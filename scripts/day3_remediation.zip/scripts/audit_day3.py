"""Day 3 full-corpus audit: EVERY image/mask of all 5 splits through the real BMADBrain path.
Run from repo root:  python scripts/audit_day3.py | tee results/day3/day3_audit.log
Writes results/day3/day3_audit.json. Exit code 1 if any hard check fails. No check is relaxed to pass.
Descriptive only: test-split numbers must not drive any design choice.
"""
import json
import platform
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from brainsentinel.data.checks import load_config  # noqa: E402
from brainsentinel.data.dataset import BMADBrain  # noqa: E402
from brainsentinel.data.palette import train_palette  # noqa: E402
from brainsentinel.data.preprocessing import (  # noqa: E402
    get_norm, load_pp_config, resolve_cfg, sha256_file)

KEYS = ["train/good", "valid/good", "valid/Ungood", "test/good", "test/Ungood"]
EXPECTED_OFFSET = {"train/good": 31, "valid/good": 0, "valid/Ungood": 0, "test/good": 0, "test/Ungood": 2}  # Day 2
DAY2 = {"valid": (0, 93756), "test": (184, 6731065, 16)}  # lesion px on background / total (/ images)
FRAC_LO, FRAC_HI = 0.05, 0.50  # arbitrary descriptive thresholds for listing brain-fraction outliers (not a check)


def _git(*a):
    try:
        return subprocess.run(["git", *a], cwd=REPO, capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        return None


def audit_key(cfg, pp, pal, key, mean, std) -> dict:
    ds = BMADBrain(cfg, pp, pal, [key])
    errs, bgs, fr, offset_files = [], Counter(), [], []
    bad = dict(nonfinite=0, out_of_range=0, nonbinary=0, lesion_px_mismatch=0, empty_brain=0)
    les_total = les_bg = les_bg_imgs = 0
    les_bg_files = []
    t0 = time.time()
    for i in range(len(ds)):
        try:
            it = ds[i]
        except Exception as e:  # record, keep going
            errs.append({"file": ds.items[i][1]["file"], "error": repr(e)[:300]})
            continue
        x = it["image"].numpy()
        bad["nonfinite"] += int(not np.isfinite(x).all())
        x01 = x[0] * std[0] + mean[0]
        bad["out_of_range"] += int(x01.min() < -1e-5 or x01.max() > 1 + 1e-5)
        brain = it["brain"].numpy()
        bad["empty_brain"] += int(brain.sum() == 0)
        bgs[it["corner_bg"]] += 1
        if it["corner_bg"] > 0:
            offset_files.append(it["file"])
        fr.append((float(brain.mean()), it["file"]))
        if "mask" in it:
            m = it["mask"].numpy()
            bad["nonbinary"] += int(not set(np.unique(m).tolist()) <= {0, 1})
            bad["lesion_px_mismatch"] += int(int(m.sum()) != int(ds.items[i][1]["lesion_px"]))
            n_bg = int(((m == 1) & ~brain).sum())
            les_total += int(m.sum())
            les_bg += n_bg
            if n_bg:
                les_bg_imgs += 1
                les_bg_files.append({"file": it["file"], "px_on_background": n_bg, "lesion_px": int(m.sum())})
    fr.sort()
    vals = [v for v, _ in fr]
    return {"n": len(ds), "errors": errs[:50], "n_errors": len(errs), **bad,
            "corner_bg_counts": {str(k): v for k, v in sorted(bgs.items())},
            "n_offset": len(offset_files), "offset_files": offset_files[:60],
            "offset_count_ok": len(offset_files) == EXPECTED_OFFSET[key],
            "brain_fraction_mean": float(np.mean(vals)) if vals else None,
            "brain_fraction_std": float(np.std(vals)) if vals else None,
            "brain_fraction_lowest": fr[:5], "brain_fraction_highest": fr[-5:],
            f"n_brain_fraction_outside_{FRAC_LO}_{FRAC_HI}": sum(1 for v in vals if v < FRAC_LO or v > FRAC_HI),
            "lesion_px_total": les_total, "lesion_px_on_background": les_bg,
            "images_with_lesion_on_background": les_bg_imgs,
            "lesion_on_background_worst": sorted(les_bg_files, key=lambda r: -r["px_on_background"])[:10],
            "seconds": round(time.time() - t0, 1)}


def main() -> int:
    cfg = resolve_cfg(load_config(REPO / "configs" / "data.yaml"))
    pp = load_pp_config()
    pal = train_palette(cfg)
    mean, std = get_norm(pp)
    res = {}
    for k in KEYS:
        res[k] = audit_key(cfg, pp, pal, k, mean, std)
        r = res[k]
        print(f"{k:13s} n={r['n']:5d} errors={r['n_errors']} nonfinite={r['nonfinite']} "
              f"out_of_range={r['out_of_range']} nonbinary={r['nonbinary']} "
              f"lesion_px_mismatch={r['lesion_px_mismatch']} empty_brain={r['empty_brain']} "
              f"offset={r['n_offset']} (expected {EXPECTED_OFFSET[k]}, ok={r['offset_count_ok']}) "
              f"brain_frac={r['brain_fraction_mean']:.3f} bg={r['corner_bg_counts']} ({r['seconds']}s)")
    hard = sum(r["n_errors"] + r["nonfinite"] + r["out_of_range"] + r["nonbinary"] + r["lesion_px_mismatch"]
               + r["empty_brain"] + int(not r["offset_count_ok"]) for r in res.values())
    v_bg = sum(res[k]["lesion_px_on_background"] for k in KEYS[1:3])
    v_tot = sum(res[k]["lesion_px_total"] for k in KEYS[1:3])
    t_bg = sum(res[k]["lesion_px_on_background"] for k in KEYS[3:])
    t_tot = sum(res[k]["lesion_px_total"] for k in KEYS[3:])
    t_imgs = sum(res[k]["images_with_lesion_on_background"] for k in KEYS[3:])
    repro = {"valid": [v_bg, v_tot], "test": [t_bg, t_tot, t_imgs],
             "valid_matches_day2": (v_bg, v_tot) == DAY2["valid"],
             "test_matches_day2": (t_bg, t_tot, t_imgs) == DAY2["test"]}
    print(f"Day 2 reproduction: valid {v_bg}/{v_tot} (Day 2: {DAY2['valid'][0]}/{DAY2['valid'][1]}) "
          f"match={repro['valid_matches_day2']}; test {t_bg}/{t_tot} in {t_imgs} imgs "
          f"(Day 2: {DAY2['test'][0]}/{DAY2['test'][1]} in {DAY2['test'][2]}) match={repro['test_matches_day2']}")
    print("HARD CHECKS:", "ALL CLEAN" if hard == 0 else f"{hard} PROBLEMS (see json)")
    index_csv = REPO / pp["index_csv"]
    meta = {"git_commit": _git("rev-parse", "HEAD"), "git_dirty": bool(_git("status", "--short")),
            "python": platform.python_version(), "numpy": np.__version__, "torch": torch.__version__,
            "index_csv_sha256": sha256_file(index_csv) if index_csv.exists() else None,
            "command": "python scripts/audit_day3.py"}
    out = REPO / "results" / "day3" / "day3_audit.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"meta": meta, "splits": res, "day2_reproduction": repro,
                               "hard_problems": hard}, indent=2) + "\n")
    return 0 if hard == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
