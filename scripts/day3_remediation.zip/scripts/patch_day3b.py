"""Remediation patcher. Every target must occur exactly once or NOTHING is written. Run once:
    python scripts/patch_day3b.py
Adds content-based hashing to preprocessing.py and tightens test_train_stats_file_if_present.
"""
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
PRE = "src/brainsentinel/data/preprocessing.py"
TST = "tests/test_preprocessing.py"

NEW_FUNCS = '''def sha256_file(path) -> str:
    """SHA-256 of the file BYTES."""
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def content_hash(hashes: dict) -> str:
    """Combine {filename: sha256(bytes)} into one hash. Pins the exact image contents a statistic used."""
    lines = [f"{n}\\t{h}" for n, h in sorted(hashes.items())]
    return hashlib.sha256("\\n".join(lines).encode()).hexdigest()


def file_content_sha256(paths) -> str:
    return content_hash({Path(p).name: sha256_file(p) for p in paths})


'''

PATCHES = {
    PRE: [("def get_norm(pp: dict)", NEW_FUNCS + "def get_norm(pp: dict)")],
    TST: [
        ("    IMAGENET_MEAN, IMAGENET_STD, REPO, file_list_sha256, get_norm, load_index_image, to_network_input)",
         "    IMAGENET_MEAN, IMAGENET_STD, REPO, file_content_sha256, file_list_sha256, get_norm,\n"
         "    load_index_image, to_network_input)"),
        ('    assert d["file_list_sha256"] == file_list_sha256(list_images(cfg, "train/good"))',
         '    files = list_images(cfg, "train/good")\n'
         '    assert d["file_list_sha256"] == file_list_sha256(files)\n'
         '    assert d["file_content_sha256"] == file_content_sha256(files)  # image BYTES, not just names\n'
         '    assert d["only_train_good_read"] is True and d["n_pixels"] > 0'),
    ],
}


def main() -> None:
    staged = {}
    for rel, pairs in PATCHES.items():
        text = (REPO / rel).read_text()
        for old, new in pairs:
            n = text.count(old)
            if n != 1:
                sys.exit(f"ABORT (nothing written): {rel}: target occurs {n}x, expected 1: {old!r}")
            text = text.replace(old, new)
        compile(text, rel, "exec")
        staged[rel] = text
    for rel, text in staged.items():
        (REPO / rel).write_text(text)
        print("patched", rel)


if __name__ == "__main__":
    main()
