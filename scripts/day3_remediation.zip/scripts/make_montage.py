"""Before/after preprocessing montage. Run from repo root:  python scripts/make_montage.py
Cases are chosen by fixed rules (below), not by eye. Columns: original RGB | recovered index (raw) |
corrected index (own corner_bg subtracted) | brain-mask METADATA (hypothesis, NOT a segmentation) |
ground-truth mask | corrected + GT overlay.
Writes results/day3/figures/day3_montage.png and results/day3/day3_montage_manifest.json (text evidence).
The 01432_76 case is a test image: it is shown only to document a known artefact, not to tune anything.
Check the BraTS/BMAD licence before committing the PNG to a public repo.
"""
import csv
import json
import sys
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from brainsentinel.data.checks import load_config, load_mask_binary, mask_path, split_dir  # noqa: E402
from brainsentinel.data.palette import load_rgb, train_palette  # noqa: E402
from brainsentinel.data.preprocessing import load_index_image, load_pp_config, resolve_cfg  # noqa: E402


def select(rows):
    by = lambda k: sorted((r for r in rows if f"{r['split']}/{r['class']}" == k), key=lambda r: r["file"])
    tr, va, te = by("train/good"), by("valid/Ungood"), by("test/Ungood")
    med = float(np.median([int(r["lesion_px"]) for r in va])) if va else 0.0
    spec = [
        ("clean background (first train/good with corner_bg 0)", "train/good", lambda: next(r for r in tr if int(r["corner_bg"]) == 0)),
        ("offset background (train/good, largest corner_bg)", "train/good", lambda: max((r for r in tr if int(r["corner_bg"]) > 0), key=lambda r: int(r["corner_bg"]))),
        ("small lesion (valid/Ungood, smallest lesion_px)", "valid/Ungood", lambda: min(va, key=lambda r: int(r["lesion_px"]))),
        ("representative abnormal (valid/Ungood, lesion_px nearest median)", "valid/Ungood", lambda: min(va, key=lambda r: abs(int(r["lesion_px"]) - med))),
        ("vertical-cut artefact, cause unknown (test/Ungood 01432_76)", "test/Ungood", lambda: next(r for r in te if r["file"] == "01432_76.png")),
        ("possible banding, HYPOTHESIS (first train/good of patient 01551)", "train/good", lambda: next(r for r in tr if r["patient"] == "01551")),
    ]
    cases, missing = [], []
    for label, key, fn in spec:
        try:
            cases.append((label, key, fn()))
        except (StopIteration, ValueError):
            missing.append(label)
            print("MISSING CASE:", label)
    return cases, missing


def main() -> int:
    cfg = resolve_cfg(load_config(REPO / "configs" / "data.yaml"))
    pp = load_pp_config()
    pal = train_palette(cfg)
    with (REPO / pp["index_csv"]).open(newline="") as f:
        rows = list(csv.DictReader(f))
    cases, missing = select(rows)
    fig, axes = plt.subplots(len(cases), 6, figsize=(13.5, 2.35 * len(cases)), squeeze=False)
    titles = ["original RGB", "recovered index (raw)", "corrected index", "brain mask (hypothesis)",
              "ground-truth mask", "corrected + GT"]
    manifest = []
    for i, (label, key, r) in enumerate(cases):
        path = split_dir(cfg, key, "img") / r["file"]
        rgb = load_rgb(path)
        raw = pal.encode(rgb)
        idx, brain, bg = load_index_image(path, pal, pp["input"]["size"])
        mp = mask_path(cfg, key, path)
        gt = load_mask_binary(mp) if mp is not None else None
        panels = [rgb, raw, idx, brain.astype(np.uint8), gt]
        for j in range(6):
            ax = axes[i, j]
            ax.set_xticks([]); ax.set_yticks([])
            if i == 0:
                ax.set_title(titles[j], fontsize=8)
            if j == 0:
                ax.imshow(rgb, interpolation="nearest")
            elif j in (1, 2):
                ax.imshow(panels[j], cmap="gray", vmin=0, vmax=255, interpolation="nearest")
            elif j == 3:
                ax.imshow(brain, cmap="gray", vmin=0, vmax=1, interpolation="nearest")
            elif j == 4:
                if gt is None:
                    ax.text(0.5, 0.5, "no mask\n(train/good)", ha="center", va="center", fontsize=8)
                else:
                    ax.imshow(gt, cmap="gray", vmin=0, vmax=1, interpolation="nearest")
            else:
                ax.imshow(idx, cmap="gray", vmin=0, vmax=255, interpolation="nearest")
                if gt is not None and gt.any():
                    ax.imshow(np.ma.masked_where(gt == 0, gt), cmap="autumn", alpha=0.5, interpolation="nearest")
                    ax.contour(gt, levels=[0.5], colors="r", linewidths=0.7)
        axes[i, 0].set_ylabel(f"{r['file']}\nbg={bg}", fontsize=7)
        axes[i, 1].set_xlabel(f"min {int(raw.min())} max {int(raw.max())}", fontsize=7)
        axes[i, 2].set_xlabel(f"min {int(idx.min())} max {int(idx.max())}", fontsize=7)
        axes[i, 3].set_xlabel(f"fraction {brain.mean():.3f}", fontsize=7)
        manifest.append({"case": label, "key": key, "file": r["file"], "patient": r["patient"], "slice": int(r["slice"]),
                         "corner_bg": bg, "raw_min": int(raw.min()), "raw_max": int(raw.max()),
                         "corrected_min": int(idx.min()), "corrected_max": int(idx.max()),
                         "brain_fraction": float(brain.mean()),
                         "gt_px": None if gt is None else int(gt.sum()),
                         "gt_px_on_background": None if gt is None else int(((gt == 1) & ~brain).sum())})
    fig.suptitle("Day 3 preprocessing: before/after. Brain mask = idx > corner background "
                 "(HYPOTHESIS, not a validated segmentation)", fontsize=9)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    out_png = REPO / "results" / "day3" / "figures" / "day3_montage.png"
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=90)
    (REPO / "results" / "day3" / "day3_montage_manifest.json").write_text(
        json.dumps({"png": str(out_png.relative_to(REPO)), "missing_cases": missing, "cases": manifest}, indent=2) + "\n")
    print("wrote", out_png, "cases:", len(cases), "missing:", missing)
    return 0 if not missing else 1


if __name__ == "__main__":
    sys.exit(main())
