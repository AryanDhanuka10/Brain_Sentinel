"""Find .ipynb files that are not valid Jupyter JSON. Dry run by default:
    python scripts/fix_notebooks.py            # report only
    python scripts/fix_notebooks.py --apply    # rewrite invalid ones as valid placeholder notebooks
The original text is preserved in a raw cell. Nothing is claimed as implemented.
"""
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
SKIP = {".git", "node_modules", ".ipynb_checkpoints", ".venv", "brain"}


def is_valid(text: str) -> bool:
    try:
        d = json.loads(text)
    except ValueError:
        return False
    return isinstance(d, dict) and d.get("nbformat") == 4 and isinstance(d.get("cells"), list)


def placeholder(name: str, text: str) -> dict:
    return {"cells": [
        {"cell_type": "markdown", "metadata": {},
         "source": [f"# {name}\n", "\n", "**PLACEHOLDER: not implemented.** The original placeholder text is "
                    "preserved in the raw cell below. Replace this notebook when its milestone is built."]},
        {"cell_type": "raw", "metadata": {}, "source": text.splitlines(keepends=True)}],
        "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                     "language_info": {"name": "python"}},
        "nbformat": 4, "nbformat_minor": 4}


def main() -> int:
    apply = "--apply" in sys.argv
    bad = 0
    for p in sorted(REPO.rglob("*.ipynb")):
        if SKIP & set(p.relative_to(REPO).parts):
            continue
        text = p.read_text(errors="replace")
        if is_valid(text):
            print("valid  ", p.relative_to(REPO))
            continue
        bad += 1
        print("INVALID", p.relative_to(REPO), "->", "rewriting" if apply else "would rewrite (use --apply)")
        if apply:
            p.write_text(json.dumps(placeholder(p.stem, text), indent=1) + "\n")
    print(f"{bad} invalid notebook(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
