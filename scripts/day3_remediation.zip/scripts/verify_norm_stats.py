"""Independent check of norm_stats.json. Run from repo root:  python scripts/verify_norm_stats.py
Does NOT use load_index_image or the fit script's arithmetic: it decodes with the palette directly and
computes mean/std EXACTLY from an integer histogram of (idx - bg) over brain pixels. Reads train/good only.
Writes results/day3/norm_verify.json; exit code 1 on any mismatch.
"""
import json
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from brainsentinel.data.checks import list_images, load_config, split_dir  # noqa: E402
from brainsentinel.data.palette import load_rgb, train_palette  # noqa: E402
from brainsentinel.data.preprocessing import (  # noqa: E402
    file_list_sha256, load_pp_config, resolve_cfg, sha256_file, content_hash)

TOL = 1e-9


def main() -> int:
    cfg = resolve_cfg(load_config(REPO / "configs" / "data.yaml"))
    pp = load_pp_config()
    d = json.loads((REPO / pp["normalize"]["train_stats_path"]).read_text())
    train_dir = split_dir(cfg, "train/good", "img")
    files = list_images(cfg, "train/good")
    pal = train_palette(cfg)
    hist = np.zeros(256, dtype=np.int64)
    hashes = {}
    for p in files:
        assert p.parent == train_dir
        idx = pal.encode(load_rgb(p))
        bg = int(idx[0, 0])
        sel = idx[idx > bg].astype(np.int64) - bg
        hist += np.bincount(sel, minlength=256)
        hashes[p.name] = sha256_file(p)
    n = int(hist.sum())
    k = np.arange(256, dtype=np.float64) / 255.0
    mean = float((hist * k).sum() / n)
    std = float(np.sqrt((hist * (k - mean) ** 2).sum() / n))
    checks = {
        "fitted_on_train_good": d["fitted_on"] == "train/good" and d["only_train_good_read"] is True,
        "n_files": d["n_images"] == len(files) == cfg["splits"]["train/good"]["expected_n"],
        "n_pixels": d["n_pixels"] == n,
        "mean_within_tol": abs(d["mean"] - mean) < TOL,
        "std_within_tol": abs(d["std"] - std) < TOL,
        "file_list_sha256": d["file_list_sha256"] == file_list_sha256(files),
        "file_content_sha256": d["file_content_sha256"] == content_hash(hashes),
    }
    res = {"recomputed": {"n_pixels": n, "mean": mean, "std": std}, "stored": {k_: d[k_] for k_ in ("n_pixels", "mean", "std")},
           "abs_diff": {"mean": abs(d["mean"] - mean), "std": abs(d["std"] - std)}, "checks": checks,
           "verdict": "PASS" if all(checks.values()) else "FAIL"}
    out = REPO / "results" / "day3" / "norm_verify.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, indent=2) + "\n")
    print(json.dumps(res, indent=2))
    return 0 if res["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
