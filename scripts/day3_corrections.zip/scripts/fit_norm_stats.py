"""Fit train/good normalisation statistics. Run from repo root:  python scripts/fit_norm_stats.py
Reads train/good only. Hard-fails (exit 1, nothing written) on any hash mismatch, missing/corrupt image,
bad corners, empty foreground or index/disk disagreement. Logic lives in brainsentinel.data.normstats.
"""
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from brainsentinel.data.normstats import StatsError, fit_train_stats, write_outputs  # noqa: E402


def main() -> int:
    try:
        stats, image_list = fit_train_stats(REPO)
    except StatsError as e:
        print(f"FAIL: {e}")
        return 1
    for p in write_outputs(REPO, stats, image_list):
        print("wrote", p.relative_to(REPO))
    print(json.dumps(stats, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
