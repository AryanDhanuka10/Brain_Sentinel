"""Day 3 full-corpus audit of all 5 splits. Run from repo root:
    python scripts/audit_day3.py | tee results/day3/day3_audit.log
Writes results/day3/day3_audit.json; exit 1 if any hard problem. No check is relaxed. Expected Day 2 values
(31 train / 2 test-Ungood offset images; lesion-on-background numbers) are COMPARED, never forced.
Test-split figures are descriptive only and must not drive any design choice.
"""
import csv
import json
import platform
import subprocess
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
import yaml

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

from brainsentinel.data.checks import list_images, load_config  # noqa: E402
from brainsentinel.data.dataset import BMADBrain  # noqa: E402
from brainsentinel.data.palette import train_palette  # noqa: E402
from brainsentinel.data.preprocessing import (  # noqa: E402
    get_norm, load_pp_config, resolve_cfg, sha256_file)

KEYS = ["train/good", "valid/good", "valid/Ungood", "test/good", "test/Ungood"]
EXPECTED_OFFSET = {"train/good": 31, "valid/good": 0, "valid/Ungood": 0, "test/good": 0, "test/Ungood": 2}  # Day 2
DAY2 = {"valid": (0, 93756), "test": (184, 6731065, 16)}
FRAC_LO, FRAC_HI = 0.05, 0.50  # descriptive listing thresholds only (not a pass/fail check)


def _git(*a):
    try:
        return subprocess.run(["git", *a], cwd=REPO, capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        return None


def integrity(cfg, rows, key) -> dict:
    """Index rows vs files on disk, expected_n, and SHA-256 of every file vs index.csv."""
    split, cls = key.split("/")
    krows = [r for r in rows if r["split"] == split and r["class"] == cls]
    files = list_images(cfg, key)
    disk, idx = {p.name: p for p in files}, {r["file"]: r for r in krows}
    mism, blank = [], []
    for name, p in disk.items():
        want = (idx.get(name) or {}).get("sha256") or ""
        if not want:
            blank.append(name)
        elif sha256_file(p) != want:
            mism.append(name)
    exp = cfg["splits"][key]["expected_n"]
    return {"n_index_rows": len(krows), "n_files": len(files), "expected_n": exp,
            "missing_files": sorted(set(idx) - set(disk))[:20], "extra_files": sorted(set(disk) - set(idx))[:20],
            "n_hash_mismatch": len(mism), "hash_mismatch_files": mism[:20],
            "n_hash_missing": len(blank), "hash_missing_files": blank[:20],
            "count_ok": len(files) == len(krows) == exp and not (set(idx) ^ set(disk))}


def audit_key(cfg, pp, pal, key, mean, std, integ) -> dict:
    out = {**integ, "expected_offset": EXPECTED_OFFSET[key]}
    zeros = dict(n=0, n_errors=0, nonfinite=0, out_of_range=0, nonbinary=0, lesion_px_mismatch=0, empty_brain=0,
                 lesion_px_total=0, lesion_px_on_background=0, images_with_lesion_on_background=0)
    try:
        ds = BMADBrain(cfg, pp, pal, [key])
    except Exception as e:  # dataset guard (index/disk mismatch, isolation, ...)
        return {**zeros, **out, "dataset_guard_error": repr(e)[:300], "n_errors": 1, "n_offset": 0, "offset_count_ok": False,
                "errors": [], "corner_bg_counts": {}, "brain_fraction_mean": None}
    errs, bgs, fr, offset_files, worst = [], Counter(), [], [], []
    c = dict(zeros)
    t0 = time.time()
    for i in range(len(ds)):
        try:
            it = ds[i]
        except Exception as e:
            errs.append({"file": ds.items[i][1]["file"], "error": repr(e)[:300]})
            continue
        x = it["image"].numpy()
        c["nonfinite"] += int(not np.isfinite(x).all())
        x01 = x[0] * std[0] + mean[0]
        c["out_of_range"] += int(x01.min() < -1e-5 or x01.max() > 1 + 1e-5)
        brain = it["brain"].numpy()
        c["empty_brain"] += int(brain.sum() == 0)
        bgs[it["corner_bg"]] += 1
        if it["corner_bg"] > 0:
            offset_files.append(it["file"])
        fr.append((float(brain.mean()), it["file"]))
        if "mask" in it:
            m = it["mask"].numpy()
            c["nonbinary"] += int(not set(np.unique(m).tolist()) <= {0, 1})
            c["lesion_px_mismatch"] += int(int(m.sum()) != int(ds.items[i][1]["lesion_px"]))
            n_bg = int(((m == 1) & ~brain).sum())
            c["lesion_px_total"] += int(m.sum())
            c["lesion_px_on_background"] += n_bg
            if n_bg:
                c["images_with_lesion_on_background"] += 1
                worst.append({"file": it["file"], "px_on_background": n_bg, "lesion_px": int(m.sum())})
    fr.sort()
    vals = [v for v, _ in fr]
    c.update(n=len(ds), n_errors=len(errs))
    return {**out, **c, "errors": errs[:50], "corner_bg_counts": {str(k): v for k, v in sorted(bgs.items())},
            "n_offset": len(offset_files), "offset_files": offset_files[:60],
            "offset_count_ok": len(offset_files) == EXPECTED_OFFSET[key],
            "brain_fraction_mean": float(np.mean(vals)) if vals else None,
            "brain_fraction_std": float(np.std(vals)) if vals else None,
            "brain_fraction_lowest": fr[:5], "brain_fraction_highest": fr[-5:],
            "n_brain_fraction_outside_listing_thresholds": sum(1 for v in vals if v < FRAC_LO or v > FRAC_HI),
            "lesion_on_background_worst": sorted(worst, key=lambda r: -r["px_on_background"])[:10],
            "seconds": round(time.time() - t0, 1)}


def main() -> int:
    cfg = resolve_cfg(load_config(REPO / "configs" / "data.yaml"))
    pp = load_pp_config()
    index_csv = REPO / pp["index_csv"]
    with index_csv.open(newline="") as f:
        rows = list(csv.DictReader(f))
    pal = train_palette(cfg)  # raises unless 256 monotone colours
    mean, std = get_norm(pp)
    by = {s: {r["patient"] for r in rows if r["split"] == s} for s in ("train", "valid", "test")}
    leak = sorted(by["train"] & (by["valid"] | by["test"]))
    overlap = sorted(by["valid"] & by["test"])
    cfg_overlap = sorted(yaml.safe_load((REPO / "configs" / "data.yaml").read_text())["patient_overlap"]["valid_test_ids"])
    integ_summary = {"patient_leakage_train_vs_valid_test": leak, "valid_test_overlap_patients": len(overlap),
                     "overlap_matches_config": overlap == cfg_overlap,
                     "palette": {"n_colours": int(len(pal.colors)), "monotone": bool(pal.is_monotone())}}
    res = {}
    for k in KEYS:
        res[k] = audit_key(cfg, pp, pal, k, mean, std, integrity(cfg, rows, k))
        r = res[k]
        print(f"{k:13s} n={r['n']:5d} errors={r['n_errors']} nonfinite={r['nonfinite']} out_of_range={r['out_of_range']} "
              f"nonbinary={r['nonbinary']} lesion_px_mismatch={r['lesion_px_mismatch']} empty_brain={r['empty_brain']} "
              f"hash_mismatch={r['n_hash_mismatch']} hash_missing={r['n_hash_missing']} count_ok={r['count_ok']} "
              f"offset={r['n_offset']} (expected {r['expected_offset']}, ok={r['offset_count_ok']}) "
              f"brain_frac={r['brain_fraction_mean']} ({r.get('seconds')}s)")
    hard = (len(leak) + int(not integ_summary["overlap_matches_config"]) + int(not pal.is_monotone())
            + int(len(pal.colors) != 256))
    for r in res.values():
        hard += (r["n_errors"] + r["nonfinite"] + r["out_of_range"] + r["nonbinary"] + r["lesion_px_mismatch"]
                 + r["empty_brain"] + r["n_hash_mismatch"] + r["n_hash_missing"] + int(not r["count_ok"])
                 + int(not r["offset_count_ok"]))
    v_bg = sum(res[k]["lesion_px_on_background"] for k in KEYS[1:3])
    v_tot = sum(res[k]["lesion_px_total"] for k in KEYS[1:3])
    t_bg = sum(res[k]["lesion_px_on_background"] for k in KEYS[3:])
    t_tot = sum(res[k]["lesion_px_total"] for k in KEYS[3:])
    t_imgs = sum(res[k]["images_with_lesion_on_background"] for k in KEYS[3:])
    repro = {"valid": [v_bg, v_tot], "test": [t_bg, t_tot, t_imgs],
             "valid_matches_day2": (v_bg, v_tot) == DAY2["valid"], "test_matches_day2": (t_bg, t_tot, t_imgs) == DAY2["test"]}
    print(f"Day 2 reproduction: valid {v_bg}/{v_tot} (Day 2 {DAY2['valid']}) match={repro['valid_matches_day2']}; "
          f"test {t_bg}/{t_tot} in {t_imgs} imgs (Day 2 {DAY2['test']}) match={repro['test_matches_day2']}")
    print("INTEGRITY:", integ_summary)
    print("HARD CHECKS:", "ALL CLEAN" if hard == 0 else f"{hard} PROBLEMS (see json)")
    meta = {"timestamp_utc": datetime.now(timezone.utc).isoformat(), "git_commit": _git("rev-parse", "HEAD"),
            "git_dirty": bool(_git("status", "--short")), "python": platform.python_version(), "numpy": np.__version__,
            "torch": torch.__version__, "index_csv_sha256": sha256_file(index_csv), "command": "python scripts/audit_day3.py"}
    out = REPO / "results" / "day3" / "day3_audit.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"meta": meta, "integrity": integ_summary, "splits": res, "day2_reproduction": repro,
                               "hard_problems": hard}, indent=2) + "\n")
    return 0 if hard == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
