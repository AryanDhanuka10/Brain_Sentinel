"""Behavioural check of a scaffold script in a TEMP copy of a minimal repo root (never touches your repo).
    python scripts/scaffold_check.py [path/to/scaffold.sh]
Checks: runs from a repo root without error; creates no new top-level 'brainsentinel/' dir; no
'brainsentinel/brainsentinel' path anywhere; overwrites none of the existing sentinel files; a second run changes
nothing (idempotent, no duplicate creation). Only what the script actually does in the temp dir is judged.
"""
import hashlib
import subprocess
import sys
import tempfile
from pathlib import Path

SENTINELS = {
    "pyproject.toml": "[project]\nname = 'sentinel'\n",
    "README.md": "sentinel readme\n",
    "configs/data.yaml": "sentinel: 1\n",
    "src/brainsentinel/__init__.py": "# sentinel\n",
    "src/brainsentinel/data/palette.py": "# sentinel palette\n",
    "tests/__init__.py": "# sentinel\n",
}


def _snapshot(root: Path) -> dict:
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file()}


def _dirs(root: Path) -> set:
    return {str(p.relative_to(root)) for p in root.rglob("*") if p.is_dir()}


def scaffold_smoke(script: Path) -> dict:
    script = Path(script)
    if not script.exists():
        return {"ok": False, "error": f"{script} not found", "checks": {}}
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        for rel, text in SENTINELS.items():
            (root / rel).parent.mkdir(parents=True, exist_ok=True)
            (root / rel).write_text(text)
        before, before_dirs = _snapshot(root), _dirs(root)
        r1 = subprocess.run(["bash", str(script.resolve())], cwd=root, capture_output=True, text=True, timeout=60)
        after1, dirs1 = _snapshot(root), _dirs(root)
        r2 = subprocess.run(["bash", str(script.resolve())], cwd=root, capture_output=True, text=True, timeout=60)
        after2, dirs2 = _snapshot(root), _dirs(root)
        nested = sorted(d for d in dirs2 if "brainsentinel/brainsentinel" in d + "/")
        checks = {
            "exit_code_zero_both_runs": r1.returncode == 0 and r2.returncode == 0,
            "no_new_top_level_brainsentinel_dir": "brainsentinel" not in dirs1 - before_dirs,
            "no_nested_brainsentinel_path": not nested,
            "existing_files_unmodified": all(after1.get(k) == v for k, v in before.items()),
            "second_run_changes_nothing": after1 == after2 and dirs1 == dirs2,
        }
        return {"ok": all(checks.values()), "checks": checks, "nested": nested,
                "new_files": sorted(set(after2) - set(before))[:30],
                "stderr_tail": (r1.stderr + r2.stderr)[-400:]}


if __name__ == "__main__":
    res = scaffold_smoke(Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "scaffold.sh"))
    print(res)
    sys.exit(0 if res["ok"] else 1)
