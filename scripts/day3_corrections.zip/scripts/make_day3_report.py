"""Build results/day3/day3_notes.md from MEASURED artefacts only and apply fixed verdict rules.
Run last, from repo root:  python scripts/make_day3_report.py

Each unresolved item is a reason with a severity and the evidence needed to close it.
  FAIL             any reason with severity critical/major: missing artefact; audit hard problems (includes hash
                   mismatches); verifier not PASS or inconsistent with norm_stats.json; pytest missing/unparseable/
                   non-zero exit/failures/errors; montage cases missing; expected notebooks missing/invalid/none;
                   nbformat unavailable (NOT RUN).
  CONDITIONAL PASS no critical/major reason, but minor ones: skipped tests (listed), Day 2 reproduction difference,
                   README status stale/absent, pyproject invalid, scaffold behaviour check failed, visual review pending.
  PASS             no reasons at all.
A missing measurement is never a successful measurement.
"""
import importlib.util
import json
import re
import subprocess
import sys
import tomllib
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
REQUIRED = ["day3_audit.json", "norm_stats.json", "norm_stats_image_list.json", "norm_verify.json",
            "day3_montage_manifest.json", "pytest_day3.log"]
SUMMARY_RE = re.compile(r"((?:\d+ (?:passed|failed|skipped|errors?|xfailed|xpassed|warnings?|deselected)(?:, )?)+) in [\d.]+s")


def R(repo: Path) -> Path:
    return repo / "results" / "day3"


def _json(repo: Path, name: str):
    p = R(repo) / name
    try:
        return json.loads(p.read_text()) if p.exists() else None
    except ValueError:
        return None


def _git(repo: Path, *a):
    try:
        return subprocess.run(["git", "-C", str(repo), *a], capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        return None


def parse_pytest(path: Path) -> dict:
    """ok only if: log exists, first line is '$ <command>', a pytest summary line exists, EXIT_CODE=0 line exists."""
    out = {"ok": False, "problems": [], "passed": 0, "failed": 0, "errors": 0, "skipped": 0, "skip_lines": [],
           "command": None, "exit_code": None, "summary_line": None}
    if not path.exists():
        out["problems"].append("log missing")
        return out
    lines = [l for l in path.read_text().splitlines() if l.strip()]
    if not lines:
        out["problems"].append("log is empty")
        return out
    if lines[0].startswith("$ ") and "pytest" in lines[0]:
        out["command"] = lines[0][2:]
    else:
        out["problems"].append("first line must be '$ <pytest command>'")
    ec = next((l for l in reversed(lines) if l.startswith("EXIT_CODE=")), None)
    if ec is None or not ec[len("EXIT_CODE="):].strip().lstrip("-").isdigit():
        out["problems"].append("no EXIT_CODE=<n> line")
    else:
        out["exit_code"] = int(ec[len("EXIT_CODE="):])
        if out["exit_code"] != 0:
            out["problems"].append(f"pytest exit code {out['exit_code']}")
    if any("no tests ran" in l for l in lines):
        out["problems"].append("'no tests ran'")
    summ = next((l for l in reversed(lines) if SUMMARY_RE.search(l)), None)
    if summ is None:
        out["problems"].append("no pytest summary line found")
    else:
        out["summary_line"] = summ.strip()
        for word, key in (("passed", "passed"), ("failed", "failed"), ("errors?", "errors"), ("skipped", "skipped")):
            m = re.search(rf"(\d+) {word}\b", summ)
            out[key] = int(m.group(1)) if m else 0
        if out["passed"] < 1:
            out["problems"].append("zero tests passed")
        if out["failed"] or out["errors"]:
            out["problems"].append(f"failed={out['failed']} errors={out['errors']}")
    out["skip_lines"] = [l for l in lines if l.startswith("SKIPPED")]
    out["ok"] = not out["problems"]
    return out


FIELD_RE = re.compile(r"^[\s>*|\-#]*(?:current\s+|project\s+)?status\**\s*[:|]", re.I)
HEAD_RE = re.compile(r"^#+\s*(?:current\s+|project\s+)?status\s*$", re.I)


def readme_status(repo: Path):
    """('ok'|'stale'|'no_status_line'|'missing', line).
    A status FIELD is a line like 'Status: ...', '**Status:** ...', '| Status | ... |', or a '## Status' heading followed by
    its first non-empty line. A stray mention of 'Day 3' elsewhere does not count. Every status field that names a
    'Day N' must have N >= 3."""
    p = repo / "README.md"
    if not p.exists():
        return "missing", None
    lines = p.read_text().splitlines()
    values = []
    for i, line in enumerate(lines):
        if FIELD_RE.match(line):
            values.append(line.strip())
        elif HEAD_RE.match(line):
            nxt = next((l.strip() for l in lines[i + 1:] if l.strip()), "")
            values.append(nxt)
    found = []
    for v in values:
        days = [int(d) for d in re.findall(r"Day\s*(\d+)", v, re.I)]
        if days:
            found.append((max(days), v))
    if not found:
        return "no_status_line", None
    stale = [v for d, v in found if d < 3]
    return ("stale", stale[0]) if stale else ("ok", found[0][1])


def check_notebooks(repo: Path) -> dict:
    try:
        import nbformat
    except ImportError:
        return {"available": False, "expected": [], "valid": [], "placeholder": [], "invalid": [], "missing": []}
    expected = set()
    listing = repo / "configs" / "expected_notebooks.txt"
    if listing.exists():
        expected |= {l.strip() for l in listing.read_text().splitlines() if l.strip() and not l.startswith("#")}
    tracked = _git(repo, "ls-files", "--", "*.ipynb")
    if tracked is not None:
        expected |= {l for l in tracked.splitlines() if l}
    else:
        expected |= {str(p.relative_to(repo)) for p in repo.rglob("*.ipynb")
                     if not ({".git", "brain", ".venv", "node_modules"} & set(p.relative_to(repo).parts))}
    res = {"available": True, "expected": sorted(expected), "valid": [], "placeholder": [], "invalid": [], "missing": []}
    for rel in sorted(expected):
        p = repo / rel
        if not p.exists():
            res["missing"].append(rel)
            continue
        try:
            nb = nbformat.read(p, as_version=4)
            nbformat.validate(nb)
        except Exception as e:
            res["invalid"].append(f"{rel}: {type(e).__name__}")
            continue
        marked = any(c.get("metadata", {}).get("brainsentinel", {}).get("placeholder") for c in nb.cells)
        no_code = not any(c.cell_type == "code" and c.source.strip() for c in nb.cells)
        res["placeholder" if (marked or no_code) else "valid"].append(rel)
    return res


def scaffold_result(repo: Path) -> dict:
    spec = importlib.util.spec_from_file_location("scaffold_check", Path(__file__).resolve().parent / "scaffold_check.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.scaffold_smoke(repo / "scaffold.sh")


def build_report(repo: Path) -> dict:
    repo = Path(repo)
    reasons = []

    def add(sev, rid, msg, evidence):
        reasons.append({"severity": sev, "id": rid, "message": msg, "evidence_to_close": evidence})

    art = {n: (_json(repo, n) if n.endswith(".json") else None) for n in REQUIRED}
    for n in REQUIRED:
        if not (R(repo) / n).exists():
            add("critical", f"MISSING_{n}", f"required artefact missing: results/day3/{n}", f"run the step that writes {n}")
    audit, norm, ver, mont = (art["day3_audit.json"], art["norm_stats.json"], art["norm_verify.json"],
                              art["day3_montage_manifest.json"])
    if audit is not None:
        if audit.get("hard_problems", 1) != 0:
            add("critical", "AUDIT_HARD", f"audit hard_problems = {audit.get('hard_problems')}",
                "fix the data/code cause listed in day3_audit.json and re-run; do not relax a check")
        d2 = audit.get("day2_reproduction", {})
        if not (d2.get("valid_matches_day2") and d2.get("test_matches_day2")):
            add("minor", "DAY2_DIFF", f"Day 2 lesion-on-background numbers not reproduced: {d2}",
                "document and explain the discrepancy in day3_notes.md")
    if ver is not None:
        if ver.get("verdict") != "PASS":
            add("critical", "VERIFY_FAIL", f"independent verification {ver.get('verdict')}: "
                f"{[k for k, v in ver.get('checks', {}).items() if not v]}", "fix cause; re-fit and re-verify")
        if norm is not None and any(ver.get("stored", {}).get(k) != norm.get(k)
                                    for k in ("n_pixels", "sum_values", "sum_squares", "mean", "std")):
            add("critical", "VERIFY_STALE", "norm_verify.json does not describe the current norm_stats.json",
                "re-run verify_norm_stats.py after the last fit")
    pt = parse_pytest(R(repo) / "pytest_day3.log")
    if not pt["ok"]:
        add("critical", "PYTEST", f"pytest evidence not acceptable: {pt['problems']}",
            "re-run: (echo \"$ python -m pytest -q\"; python -m pytest -q 2>&1; echo \"EXIT_CODE=$?\") | tee results/day3/pytest_day3.log")
    if pt["skipped"]:
        add("minor", "SKIPPED", f"{pt['skipped']} skipped test(s): {pt['skip_lines']}",
            "justify each skip in notes or make it run")
    if mont is not None:
        if mont.get("missing_cases") or len(mont.get("cases", [])) != 6:
            add("critical", "MONTAGE_CASES", f"montage has {len(mont.get('cases', []))}/6 cases; missing {mont.get('missing_cases')}",
                "locate the missing images or document why they do not exist; never substitute arbitrary ones")
    vr = _json(repo, "visual_review.json")
    if not (vr and vr.get("reviewed") is True and vr.get("reviewer") and vr.get("findings")):
        add("minor", "VISUAL_REVIEW_PENDING", "no completed results/day3/visual_review.json",
            "a human views the montage and fills reviewed/reviewer/findings")
    nb = check_notebooks(repo)
    if not nb["available"]:
        add("critical", "NBFORMAT_MISSING", "nbformat not installed: notebook validation NOT RUN", "pip install nbformat")
    else:
        if not nb["expected"]:
            add("critical", "NO_NOTEBOOKS", "no expected notebooks found (empty set is not valid)",
                "track the notebooks or list them in configs/expected_notebooks.txt")
        if nb["missing"]:
            add("critical", "NOTEBOOK_MISSING", f"missing notebooks: {nb['missing']}", "restore or remove from the expected list")
        if nb["invalid"]:
            add("critical", "NOTEBOOK_INVALID", f"invalid notebooks: {nb['invalid']}", "python scripts/fix_notebooks.py --apply")
    rs, line = readme_status(repo)
    if rs != "ok":
        add("minor", f"README_{rs.upper()}", f"README status check: {rs} ({line})", "update the Status line to Day 3 state")
    try:
        t = tomllib.loads((repo / "pyproject.toml").read_text())
        if not (t.get("project", {}).get("name") and "pytest" in t.get("tool", {})):
            raise ValueError("missing project.name or tool.pytest")
    except Exception as e:
        add("minor", "PYPROJECT", f"pyproject.toml not valid: {e}", "add project metadata and pytest config")
    sc = scaffold_result(repo)
    if not sc["ok"]:
        add("minor", "SCAFFOLD", f"scaffold behaviour check failed: {sc.get('error') or sc['checks']}",
            "fix scaffold.sh until scripts/scaffold_check.py passes")
    crit = [r for r in reasons if r["severity"] in ("critical", "major")]
    verdict = "FAIL" if crit else ("CONDITIONAL PASS" if reasons else "PASS")

    L = ["# Day 3 notes (generated by scripts/make_day3_report.py from measured artefacts only)", "",
         f"- Git commit: {_git(repo, 'rev-parse', 'HEAD') or 'MISSING'}",
         f"- Working tree: {(_git(repo, 'status', '--short') or 'clean') if _git(repo, 'rev-parse', 'HEAD') else 'MISSING'}",
         f"- **Verdict: {verdict}**", "", "## Unresolved issues (severity, evidence required to close)"]
    L += [f"- [{r['severity']}] {r['id']}: {r['message']}. Evidence: {r['evidence_to_close']}" for r in reasons] or ["- none"]
    L += ["", "## Tests", f"- command: `{pt['command']}`", f"- exit code: {pt['exit_code']}",
          f"- summary: `{pt['summary_line']}`; passed {pt['passed']}, failed {pt['failed']}, errors {pt['errors']}, skipped {pt['skipped']}"]
    L += [f"- {s}" for s in pt["skip_lines"]] + [f"- parse problems: {pt['problems']}" if pt["problems"] else "- log parsed cleanly"]
    L += ["", "## Normalisation statistics (train/good)"]
    if norm:
        L += [f"- images {norm['n_images']}, pixels {norm['n_pixels']}, S1 {norm['sum_values']}, S2 {norm['sum_squares']}",
              f"- mean {norm['mean']:.12f}, std {norm['std']:.12f}", f"- rule: {norm['pixel_rule']}",
              f"- content sha256 {norm['file_content_sha256']}", f"- index hash status: {norm['index_sha256_status']}",
              f"- fit commit {norm['git_commit']} (dirty={norm['git_dirty']}), python {norm['python']}, numpy {norm['numpy']}"]
    else:
        L.append("- MISSING")
    if ver:
        L += [f"- independent verification: {ver['verdict']}; |dmean| {ver['abs_diff']['mean']:.2e}, |dstd| {ver['abs_diff']['std']:.2e}; "
              f"tolerance {ver['tolerances']}"]
    L += ["", "## Full-corpus audit"]
    if audit:
        L += [f"- meta: {audit.get('meta')}", f"- integrity: {audit.get('integrity')}", f"- hard_problems: {audit['hard_problems']}",
              f"- Day 2 reproduction: {audit.get('day2_reproduction')}", "",
              "| split | n | errors | nonfinite | out_of_range | nonbinary | lesion_px_mismatch | empty_brain | hash_mismatch | offset (expected) | brain frac |",
              "|---|---|---|---|---|---|---|---|---|---|---|"]
        for k, r in audit["splits"].items():
            L.append(f"| {k} | {r.get('n')} | {r.get('n_errors')} | {r.get('nonfinite')} | {r.get('out_of_range')} | {r.get('nonbinary')} | "
                     f"{r.get('lesion_px_mismatch')} | {r.get('empty_brain')} | {r.get('n_hash_mismatch')} | {r.get('n_offset')} ({r.get('expected_offset')}) | "
                     f"{r.get('brain_fraction_mean')} |")
    else:
        L.append("- MISSING")
    L += ["", "## Visual evidence", f"- {mont['png'] if mont else 'MISSING'} (foreground = idx > corner background, a HYPOTHESIS, not a segmentation)",
          "- 01432_76 vertical cut and 01551 banding are HYPOTHESES until a human review is recorded in visual_review.json"]
    L += [f"- {c['file']} ({c['key']}): bg {c['corner_bg']}, gt px {c['gt_px']}" for c in (mont or {}).get("cases", [])]
    L += ["", "## Repo checks", f"- README: {rs} ({line})", f"- notebooks: valid {nb['valid']}, placeholders {nb['placeholder']}, invalid {nb['invalid']}, missing {nb['missing']}",
          f"- scaffold: {sc.get('checks') or sc.get('error')}", "",
          "## Remaining limitations (standing)",
          "- Foreground mask is not a validated segmentation; test-split numbers are descriptive only.",
          "- Image-level labels are confounded with patient/volume; valid/test share 10 patients (sensitivity run exists).",
          "- That valid/test were not opened during fitting is evidenced by code, the recorded image list and a read-spy test, not provable from outputs alone.", ""]
    return {"verdict": verdict, "reasons": reasons, "text": "\n".join(L)}


def main() -> int:
    rep = build_report(REPO)
    R(REPO).mkdir(parents=True, exist_ok=True)
    (R(REPO) / "day3_notes.md").write_text(rep["text"])
    print("\n".join(rep["text"].splitlines()[:14]))
    return 0 if rep["verdict"] != "FAIL" else 1


if __name__ == "__main__":
    sys.exit(main())
