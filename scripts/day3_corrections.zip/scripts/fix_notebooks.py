"""Validate notebooks with nbformat; optionally repair. Dry run by default:
    python scripts/fix_notebooks.py            # report only, modifies nothing
    python scripts/fix_notebooks.py --apply    # back up each invalid file (*.bak) then repair/wrap it
Repair keeps every original cell (when the file is JSON with a 'cells' list) or wraps the original text verbatim in
a raw cell under a markdown cell that says PLACEHOLDER (metadata brainsentinel.placeholder = true). No analysis or
results are ever invented. Requires: pip install nbformat
"""
import json
import shutil
import sys
from pathlib import Path

import nbformat
from nbformat.v4 import new_markdown_cell, new_notebook, new_raw_cell

REPO = Path(__file__).resolve().parents[1]
SKIP = {".git", "node_modules", ".ipynb_checkpoints", ".venv", "brain"}
PLACEHOLDER_MD = ("**PLACEHOLDER: not implemented.** The original file content is preserved verbatim in the raw "
                  "cell below. Replace this notebook when its milestone is built.")


def is_valid(path: Path):
    """(True, nb) if nbformat can read and validate it, else (False, error string)."""
    try:
        nb = nbformat.reads(path.read_text(errors="replace"), as_version=4)
        nbformat.validate(nb)
        return True, nb
    except Exception as e:  # json errors, NBFormatError, ValidationError
        return False, f"{type(e).__name__}: {str(e)[:200]}"


def is_placeholder(nb) -> bool:
    marked = any(c.get("metadata", {}).get("brainsentinel", {}).get("placeholder") for c in nb.cells)
    return marked or not any(c.cell_type == "code" and c.source.strip() for c in nb.cells)


def _repair(text: str):
    """Keep all cells if the text is JSON with a cells list and becomes valid after adding missing top-level keys."""
    try:
        d = json.loads(text)
    except ValueError:
        return None
    if not (isinstance(d, dict) and isinstance(d.get("cells"), list)):
        return None
    d.setdefault("metadata", {})
    d.setdefault("nbformat", 4)
    d.setdefault("nbformat_minor", 5)
    try:
        nb = nbformat.from_dict(d)
        nbformat.validator.normalize(nb)
        nbformat.validate(nb)
        return nb
    except Exception:
        return None


def _wrap(name: str, text: str):
    return new_notebook(cells=[
        new_markdown_cell(f"# {name}\n\n{PLACEHOLDER_MD}", metadata={"brainsentinel": {"placeholder": True}}),
        new_raw_cell(text, metadata={"brainsentinel": {"original_text": True}})],
        metadata={"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}})


def _backup(path: Path) -> Path:
    b = path.with_name(path.name + ".bak")
    i = 1
    while b.exists():
        b = path.with_name(f"{path.name}.bak{i}")
        i += 1
    shutil.copy2(path, b)
    return b


def process(path: Path, apply: bool = False) -> dict:
    ok, info = is_valid(path)
    if ok:
        return {"path": str(path), "status": "placeholder" if is_placeholder(info) else "valid", "modified": False}
    text = path.read_text(errors="replace")
    action = "repair_keep_cells" if _repair(text) is not None else "wrap_as_placeholder"
    res = {"path": str(path), "status": "invalid", "error": info, "action": action, "modified": False}
    if apply:
        res["backup"] = str(_backup(path))
        nb = _repair(text) if action == "repair_keep_cells" else _wrap(path.stem, text)
        nbformat.validate(nb)
        nbformat.write(nb, path)
        res["modified"] = True
    return res


def find_notebooks(root: Path) -> list[Path]:
    return [p for p in sorted(root.rglob("*.ipynb")) if not (SKIP & set(p.relative_to(root).parts))]


def main() -> int:
    apply = "--apply" in sys.argv
    nbs = find_notebooks(REPO)
    if not nbs:
        print("NO NOTEBOOKS FOUND (an empty list is not a pass)")
        return 1
    results = [process(p, apply) for p in nbs]
    for r in results:
        print(json.dumps(r))
    invalid = [r for r in results if r["status"] == "invalid"]
    print(f"{len(results)} notebooks: {len(invalid)} invalid, "
          f"{sum(r['modified'] for r in results)} modified ({'applied' if apply else 'dry run'})")
    return 0 if not invalid or apply else 1


if __name__ == "__main__":
    sys.exit(main())
