"""INDEPENDENT verification of norm_stats.json. Run from repo root:  python scripts/verify_norm_stats.py
Imports nothing from brainsentinel: own config reading, own palette recovery, own pixel rule, own hashing.

Pixel rule (re-implemented here, documented in src/brainsentinel/data/normstats.py):
  bg = common value of the 4 corner pixels (identical, <= MAX_BG); included = idx > bg; value = idx - bg;
  empty foreground, differing corners, bg > MAX_BG, unknown colour, wrong size or alpha != 255 are errors.
Comparison: n, sum and sum of squares must match EXACTLY (integers). mean/std must agree within 1e-12: both
programs derive them from the same exact integers with one float64 division/sqrt, so the expected disagreement
is a few ulp (~1e-16), amplified at most ~3x by the mean^2 subtraction; 1e-12 leaves ~1000x margin without
hiding a real change (a single changed pixel moves the sums by >= 1 integer unit, caught exactly).
Exit code 1 on any failure; writes results/day3/norm_verify.json.
"""
import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import yaml
from PIL import Image

MAX_BG = 10  # train-derived; tests/test_normstats.py asserts it equals palette.MAX_BG
SIZE = 240
TOL = 1e-12


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _rgb_keys(path: Path) -> np.ndarray:
    with Image.open(path) as im:
        a = np.asarray(im.convert("RGBA"))
    if a.shape != (SIZE, SIZE, 4):
        raise ValueError(f"shape {a.shape}")
    if not (a[..., 3] == 255).all():
        raise ValueError("alpha != 255")
    a = a[..., :3].astype(np.uint32)
    return (a[..., 0] << 16) | (a[..., 1] << 8) | a[..., 2]


def _foreground(idx: np.ndarray) -> tuple[int, np.ndarray]:
    c = {int(idx[0, 0]), int(idx[0, -1]), int(idx[-1, 0]), int(idx[-1, -1])}
    if len(c) != 1:
        raise ValueError(f"corner pixels differ: {sorted(c)}")
    bg = c.pop()
    if bg > MAX_BG:
        raise ValueError(f"corner background {bg} > {MAX_BG}")
    fg = idx > bg
    if not fg.any():
        raise ValueError("empty foreground")
    return bg, fg


def _lines_hash(lines: list[str]) -> str:
    return hashlib.sha256("\n".join(lines).encode()).hexdigest()


def verify(repo: Path) -> dict:
    repo = Path(repo)
    cfg = yaml.safe_load((repo / "configs" / "data.yaml").read_text())
    pp = yaml.safe_load((repo / "configs" / "preprocess.yaml").read_text())
    root = Path(cfg["root"])
    root = root if root.is_absolute() else repo / root
    train_dir = root / "train" / "good"
    expected_n = cfg["splits"]["train/good"]["expected_n"]
    problems: list[str] = []
    stats = json.loads((repo / pp["normalize"]["train_stats_path"]).read_text())
    lst = json.loads((repo / "results" / "day3" / "norm_stats_image_list.json").read_text())

    files = sorted(train_dir.glob("*.png"))
    names = [p.name for p in files]
    seen = np.zeros(1 << 24, dtype=bool)  # pass 1: own palette from train/good only
    for p in files:
        try:
            seen[_rgb_keys(p).ravel()] = True
        except Exception as e:
            problems.append(f"{p.name}: unreadable ({e})")
    keys = np.flatnonzero(seen).astype(np.uint32)
    comps = np.stack([(keys >> 16) & 255, (keys >> 8) & 255, keys & 255], axis=1).astype(np.int16)
    pal_ok = len(keys) == 256 and bool((np.diff(comps, axis=0) >= 0).all())
    if not pal_ok:
        problems.append(f"palette not 256 monotone colours (got {len(keys)})")

    hist = np.zeros(256, dtype=np.int64)  # pass 2: exact integer histogram of (idx - bg) over included pixels
    hashes: dict[str, str] = {}
    for p in files:
        hashes[p.name] = _sha(p)
        try:
            pk = _rgb_keys(p)
            pos = np.clip(np.searchsorted(keys, pk), 0, len(keys) - 1)
            if not (keys[pos] == pk).all():
                raise ValueError("colour outside palette")
            idx = pos.astype(np.int64)
            bg, fg = _foreground(idx)
            hist += np.bincount(idx[fg] - bg, minlength=256)
        except Exception as e:
            problems.append(f"{p.name}: {e}")
    k = np.arange(256, dtype=np.int64)
    n, s1, s2 = int(hist.sum()), int((hist * k).sum()), int((hist * k * k).sum())
    mean = s1 / (255 * n) if n else float("nan")
    std = max(s2 / (255 * 255 * n) - mean * mean, 0.0) ** 0.5 if n else float("nan")

    idx_rows = []
    index_path = repo / pp["index_csv"]
    if index_path.exists():
        with index_path.open(newline="") as f:
            idx_rows = [r for r in csv.DictReader(f) if r["split"] == "train" and r["class"] == "good"]
    sha_idx = {r["file"]: (r.get("sha256") or "") for r in idx_rows}
    other = {q.name for sub in ("valid", "test") for q in (root / sub).glob("*/img/*.png")}
    list_paths = [e["path"] for e in lst]
    list_map = {e["path"]: e["sha256"] for e in lst}
    own_content = _lines_hash([f"{n_}\t{hashes[n_]}" for n_ in sorted(hashes)])
    own_list = _lines_hash([f"train/good/{n_}\t{hashes[n_]}" for n_ in sorted(hashes)])

    checks = {
        "stats_metadata": (stats.get("fitted_on") == "train/good" and stats.get("split") == "train"
                           and stats.get("group") == "good" and stats.get("hash_algorithm") == "sha256"
                           and stats.get("only_train_good_read") is True),
        "n_images_equals_disk_and_expected": stats.get("n_images") == len(files) == expected_n,
        "no_problems_reading_images": not problems,
        "image_list_only_train_good": all(p_.startswith("train/good/") and ".." not in p_ for p_ in list_paths),
        "image_list_equals_disk": sorted(list_paths) == sorted(f"train/good/{n_}" for n_ in names),
        "no_valid_test_filename_collision": not (set(names) & other),
        "n_pixels_exact": stats.get("n_pixels") == n,
        "sum_values_exact": stats.get("sum_values") == s1,
        "sum_squares_exact": stats.get("sum_squares") == s2,
        "mean_within_tol": abs(stats.get("mean", float("nan")) - mean) <= TOL,
        "std_within_tol": abs(stats.get("std", float("nan")) - std) <= TOL,
        "file_list_sha256": stats.get("file_list_sha256") == _lines_hash(sorted(names)),
        "file_content_sha256": stats.get("file_content_sha256") == own_content,
        "image_list_sha256": stats.get("image_list_sha256") == own_list,
        "image_list_hashes_match_current_bytes": all(list_map.get(f"train/good/{n_}") == h for n_, h in hashes.items()),
        "index_rows_cover_disk_exactly": set(sha_idx) == set(names) and len(idx_rows) == len(names),
        "index_hashes_all_present_and_equal": bool(idx_rows) and all(sha_idx.get(n_) == h for n_, h in hashes.items()),
    }
    return {"verdict": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "problems": problems[:50],
            "tolerances": {"mean_std_abs": TOL, "integers": "exact"},
            "recomputed": {"n_pixels": n, "sum_values": s1, "sum_squares": s2, "mean": mean, "std": std,
                           "file_content_sha256": own_content},
            "stored": {k_: stats.get(k_) for k_ in ("n_pixels", "sum_values", "sum_squares", "mean", "std",
                                                     "file_content_sha256")},
            "abs_diff": {"mean": abs(stats.get("mean", float("nan")) - mean),
                         "std": abs(stats.get("std", float("nan")) - std)},
            "note": "Whether valid/test were opened during FITTING cannot be proven from artefacts alone; this "
                    "checks the recorded image list and name collisions. See tests/test_normstats.py (read spy)."}


def main() -> int:
    repo = Path(__file__).resolve().parents[1]
    res = verify(repo)
    out = repo / "results" / "day3" / "norm_verify.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, indent=2) + "\n")
    print(json.dumps(res, indent=2))
    return 0 if res["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
