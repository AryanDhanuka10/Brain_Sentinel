"""Train-only normalisation statistics (the FITTER). scripts/verify_norm_stats.py re-derives everything independently.

PIXEL RULE (the single definition both programs implement):
  1. idx = palette index of the PNG (uint8).
  2. bg  = common value of the four corner pixels; they must be identical and <= MAX_BG (10), else error.
  3. included pixels = idx > bg; value = idx - bg (integer 1..255). An image with no included pixel is an error.
Statistics are accumulated as EXACT integers (count, sum, sum of squares); only the final divisions use floats:
  mean = S1 / (255 n),  std = sqrt(S2 / (255^2 n) - mean^2).
Every failure raises StatsError. Nothing is skipped silently.
"""
from __future__ import annotations

import csv
import hashlib
import importlib.metadata as md
import platform
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import yaml

from .checks import list_images, split_dir
from .palette import train_palette
from .preprocessing import content_hash, file_list_sha256, load_index_image, sha256_file

KEY = "train/good"
PIXEL_RULE = ("bg = common value of the 4 corner pixels of the palette index (identical, <= MAX_BG=10); "
              "included = idx > bg; value = idx - bg; empty foreground is an error")


class StatsError(RuntimeError):
    """Hard failure while fitting or verifying statistics."""


def image_list_hash(entries: list[dict]) -> str:
    lines = [f"{e['path']}\t{e['sha256']}" for e in sorted(entries, key=lambda e: e["path"])]
    return hashlib.sha256("\n".join(lines).encode()).hexdigest()


def _git(repo: Path, *a: str):
    try:
        return subprocess.run(["git", "-C", str(repo), *a], capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        return None


def _ver(pkg: str):
    try:
        return md.version(pkg)
    except Exception:
        return None


def fit_train_stats(repo: Path, require_index_hashes: bool = True) -> tuple[dict, list[dict]]:
    """Fit on train/good ONLY. Returns (stats, image_list). Raises StatsError on any problem."""
    repo = Path(repo)
    cfg = yaml.safe_load((repo / "configs" / "data.yaml").read_text())
    pp = yaml.safe_load((repo / "configs" / "preprocess.yaml").read_text())
    root = Path(cfg["root"])
    cfg["root"] = str(root if root.is_absolute() else repo / root)
    train_dir = split_dir(cfg, KEY, "img")
    files = list_images(cfg, KEY)
    expected = cfg["splits"][KEY]["expected_n"]
    if len(files) != expected:
        raise StatsError(f"{KEY}: {len(files)} files on disk, expected {expected}")
    if any(p.parent != train_dir for p in files):
        raise StatsError("a file outside train/good was listed")

    index_path = repo / pp["index_csv"]
    rows = []
    if index_path.exists():
        with index_path.open(newline="") as f:
            rows = [r for r in csv.DictReader(f) if r["split"] == "train" and r["class"] == "good"]
    names = {p.name for p in files}
    if rows:
        in_index = {r["file"] for r in rows}
        if in_index != names or len(rows) != len(in_index):
            raise StatsError(f"index/disk mismatch: disk-only {sorted(names - in_index)[:5]}, "
                             f"index-only {sorted(in_index - names)[:5]}, rows {len(rows)}")
    elif require_index_hashes:
        raise StatsError(f"no train rows in {index_path} (cannot cross-check hashes)")
    sha_idx = {r["file"]: (r.get("sha256") or "") for r in rows}
    blank = [n for n in names if not sha_idx.get(n)]
    if require_index_hashes and blank:
        raise StatsError(f"{len(blank)} train files have no sha256 in index.csv (e.g. {sorted(blank)[:3]})")

    hashes = {p.name: sha256_file(p) for p in files}
    bad = sorted(n for n, h in hashes.items() if sha_idx.get(n) and sha_idx[n] != h)
    if bad:
        raise StatsError(f"{len(bad)} files differ from index.csv sha256 (e.g. {bad[:3]})")
    status = ("verified_all" if rows and not blank else
              f"partial: {len(names) - len(blank)}/{len(names)}" if rows else "unavailable")

    try:
        pal = train_palette(cfg)
    except Exception as e:
        raise StatsError(f"palette build failed: {e!r}") from e
    size = int(pp["input"]["size"])
    n = s1 = s2 = 0
    for p in files:
        try:
            idx, brain, _ = load_index_image(p, pal, size)
        except Exception as e:
            raise StatsError(f"{p.name}: {e}") from e
        if not brain.any():
            raise StatsError(f"{p.name}: empty foreground")
        v = idx[brain].astype(np.int64)
        n += int(v.size)
        s1 += int(v.sum())
        s2 += int((v * v).sum())
    mean = s1 / (255 * n)
    std = max(s2 / (255 * 255 * n) - mean * mean, 0.0) ** 0.5

    image_list = [{"path": f"train/good/{p.name}", "sha256": hashes[p.name]} for p in files]
    stats = {
        "schema": 1, "dataset": "BMAD Brain (BraTS2021 FLAIR 2D axial)", "split": "train", "group": "good",
        "fitted_on": KEY, "only_train_good_read": True, "n_images": len(files), "expected_n_images": expected,
        "n_pixels": n, "sum_values": s1, "sum_squares": s2, "scale": 255, "pixel_rule": PIXEL_RULE,
        "mean": mean, "std": std, "hash_algorithm": "sha256",
        "file_list_sha256": file_list_sha256(files), "file_content_sha256": content_hash(hashes),
        "image_list_sha256": image_list_hash(image_list), "index_sha256_status": status,
        "index_csv_sha256": sha256_file(index_path) if index_path.exists() else None,
        "data_yaml_sha256": sha256_file(repo / "configs" / "data.yaml"),
        "preprocess_yaml_sha256": sha256_file(repo / "configs" / "preprocess.yaml"),
        "git_commit": _git(repo, "rev-parse", "HEAD"), "git_dirty": bool(_git(repo, "status", "--short")),
        "python": platform.python_version(), "numpy": _ver("numpy"), "pillow": _ver("pillow"),
        "pyyaml": _ver("pyyaml"), "torch": _ver("torch"), "created_utc": datetime.now(timezone.utc).isoformat(),
    }
    return stats, image_list


def write_outputs(repo: Path, stats: dict, image_list: list[dict]) -> list[Path]:
    import json
    repo = Path(repo)
    pp = yaml.safe_load((repo / "configs" / "preprocess.yaml").read_text())
    targets = [(repo / pp["normalize"]["train_stats_path"], stats),
               (repo / "results" / "day3" / "norm_stats.json", stats),
               (repo / "results" / "day3" / "norm_stats_image_list.json", image_list)]
    for path, obj in targets:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(obj, indent=1) + "\n")
    return [t[0] for t in targets]
