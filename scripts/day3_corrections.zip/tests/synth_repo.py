"""Synthetic BMAD-like repo builder for ISOLATED unit tests.
This is NOT BMAD data. A pass here validates logic only and says nothing about the real dataset."""
from __future__ import annotations

import csv
import hashlib
from pathlib import Path

import numpy as np
import yaml
from PIL import Image

SIZE = 240
PAL = np.stack([np.arange(256)] * 3, axis=1).astype(np.uint8)  # 256 monotone colours
CORNERS = ((0, 0), (0, -1), (-1, 0), (-1, -1))
OTHERS = [("valid", "good"), ("valid", "Ungood"), ("test", "good"), ("test", "Ungood")]


def train_idx(bg: int, k: int) -> np.ndarray:
    idx = np.roll((np.arange(SIZE * SIZE) % 256).reshape(SIZE, SIZE).astype(np.uint8), k * 7, axis=1)
    for r, c in CORNERS:
        idx[r, c] = bg
    return idx


def save_png(idx: np.ndarray, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rgba = np.dstack([PAL[idx], np.full(idx.shape, 255, np.uint8)])
    Image.fromarray(rgba, "RGBA").save(path)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_repo(root: Path, bgs=(0, 3, 6, 10), overrides: dict | None = None, corrupt: str | None = None) -> dict:
    """Train image k has corner background bgs[k] unless overridden by overrides[k] (a full uint8 array)."""
    overrides = overrides or {}
    brain = root / "data" / "raw" / "Brain"
    train_arrays, names = {}, []
    for k, bg in enumerate(bgs):
        idx = overrides.get(k, train_idx(bg, k))
        name = f"{k:05d}_60.png"
        save_png(idx, brain / "train" / "good" / name)
        train_arrays[name] = idx
        names.append(name)
    if corrupt:
        (brain / "train" / "good" / corrupt).write_bytes(b"not a png")
    rows = []
    for k, name in enumerate(names):
        idx = train_arrays[name]
        rows.append({"split": "train", "class": "good", "file": name, "patient": f"{k:05d}", "slice": 60,
                     "slice_bin": "60s", "lesion_px": "", "corner_bg": int(idx[0, 0]),
                     "sha256": sha(brain / "train" / "good" / name)})
    for j, (split, cls) in enumerate(OTHERS):
        name = f"{10000 + j}_60.png"
        idx = train_idx(0, 20 + j)
        save_png(idx, brain / split / cls / "img" / name)
        m = np.zeros((SIZE, SIZE, 4), np.uint8)
        m[..., 3] = 255
        if cls == "Ungood":
            m[120, 120, :3] = (56, 55, 77)
        (brain / split / cls / "label").mkdir(parents=True, exist_ok=True)
        Image.fromarray(m, "RGBA").save(brain / split / cls / "label" / name)
        rows.append({"split": split, "class": cls, "file": name, "patient": str(10000 + j), "slice": 60,
                     "slice_bin": "60s", "lesion_px": 1 if cls == "Ungood" else 0, "corner_bg": 0,
                     "sha256": sha(brain / split / cls / "img" / name)})
    (root / "data" / "processed").mkdir(parents=True, exist_ok=True)
    with (root / "data" / "processed" / "index.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    (root / "configs").mkdir(exist_ok=True)
    splits = {"train/good": {"img_dir": ".", "mask_dir": None, "expected_n": len(bgs)}}
    splits.update({f"{s}/{c}": {"img_dir": "img", "mask_dir": "label", "expected_n": 1} for s, c in OTHERS})
    (root / "configs" / "data.yaml").write_text(yaml.safe_dump({"root": "data/raw/Brain", "image_size": SIZE,
                                                                 "splits": splits}))
    (root / "configs" / "preprocess.yaml").write_text(yaml.safe_dump({
        "index_csv": "data/processed/index.csv", "input": {"size": SIZE},
        "normalize": {"mode": "imagenet", "train_stats_path": "data/processed/norm_stats.json"}}))
    return {"repo": root, "names": names, "arrays": train_arrays, "brain": brain}


def expected_sums(arrays: dict) -> tuple[int, int, int]:
    """Independent expectation (plain numpy, no project code): n, S1, S2 of (idx - bg) over idx > bg."""
    n = s1 = s2 = 0
    for idx in arrays.values():
        bg = int(idx[0, 0])
        v = idx[idx > bg].astype(np.int64) - bg
        n += v.size
        s1 += int(v.sum())
        s2 += int((v * v).sum())
    return n, s1, s2


def rewrite_index(repo: Path, fn) -> None:
    p = repo / "data" / "processed" / "index.csv"
    with p.open(newline="") as f:
        rows = list(csv.DictReader(f))
    fn(rows)
    with p.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
