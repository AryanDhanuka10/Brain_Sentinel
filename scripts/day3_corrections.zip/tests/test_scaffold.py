"""scaffold.sh behaviour tests. The synth_* tests use throwaway scripts to prove the CHECKER detects each failure
mode. test_repo_scaffold_* runs the real scaffold.sh inside a temp copy of a minimal repo root."""
import importlib.util
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location("scaffold_check", REPO / "scripts" / "scaffold_check.py")
sc = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sc)


def _script(tmp_path, body):
    p = tmp_path / "s.sh"
    p.write_text(body)
    return p


def test_synth_safe_idempotent_scaffold_passes(tmp_path):
    r = sc.scaffold_smoke(_script(tmp_path, "mkdir -p docs/figures\n[ -f docs/figures/.gitkeep ] || touch docs/figures/.gitkeep\n"))
    assert r["ok"], r["checks"]


def test_synth_detects_nested_project_dir(tmp_path):
    r = sc.scaffold_smoke(_script(tmp_path, "mkdir -p brainsentinel/src/brainsentinel/data\n"))
    assert not r["ok"] and not r["checks"]["no_new_top_level_brainsentinel_dir"]


def test_synth_detects_nested_package_dir(tmp_path):
    r = sc.scaffold_smoke(_script(tmp_path, "mkdir -p src/brainsentinel/brainsentinel\n"))
    assert not r["ok"] and not r["checks"]["no_nested_brainsentinel_path"]


def test_synth_detects_overwritten_existing_file(tmp_path):
    r = sc.scaffold_smoke(_script(tmp_path, "echo changed > src/brainsentinel/data/palette.py\n"))
    assert not r["ok"] and not r["checks"]["existing_files_unmodified"]


def test_synth_detects_non_idempotent_duplicate_creation(tmp_path):
    r = sc.scaffold_smoke(_script(tmp_path, 'touch "f_$(date +%s%N)"\n'))
    assert not r["ok"] and not r["checks"]["second_run_changes_nothing"]


def test_synth_detects_nonzero_exit(tmp_path):
    r = sc.scaffold_smoke(_script(tmp_path, "exit 3\n"))
    assert not r["ok"] and not r["checks"]["exit_code_zero_both_runs"]


def test_synth_missing_script_is_not_ok(tmp_path):
    assert not sc.scaffold_smoke(tmp_path / "nope.sh")["ok"]


def test_repo_scaffold_has_no_nested_dirs_and_is_idempotent():
    r = sc.scaffold_smoke(REPO / "scaffold.sh")
    assert r["ok"], (r.get("error"), r["checks"], r.get("nested"), r.get("stderr_tail"))
