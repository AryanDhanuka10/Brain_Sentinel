"""Verdict-logic tests for scripts/make_day3_report.py. All artefacts here are SYNTHETIC: they prove the decision
rules (missing/empty/failed evidence can never produce PASS), not that the real Day 3 data passed."""
import importlib.util
import json
from pathlib import Path

import pytest

nbformat = pytest.importorskip("nbformat")
from nbformat.v4 import new_code_cell, new_markdown_cell, new_notebook  # noqa: E402

REPO = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location("make_day3_report", REPO / "scripts" / "make_day3_report.py")
rep = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(rep)

STATS = {"n_images": 7500, "n_pixels": 100, "sum_values": 5, "sum_squares": 7, "mean": 0.5, "std": 0.25,
         "pixel_rule": "rule", "file_content_sha256": "a" * 64, "index_sha256_status": "verified_all",
         "git_commit": "c" * 40, "git_dirty": False, "python": "3.12", "numpy": "2"}
GOOD_LOG = "$ python -m pytest -q\n.....\n82 passed in 48.60s\nEXIT_CODE=0\n"


def _w(p: Path, text):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text if isinstance(text, str) else json.dumps(text))


def make_good(root: Path) -> Path:
    r = root / "results" / "day3"
    _w(r / "day3_audit.json", {"meta": {}, "integrity": {}, "hard_problems": 0,
                               "day2_reproduction": {"valid_matches_day2": True, "test_matches_day2": True},
                               "splits": {"train/good": {"n": 7500}}})
    _w(r / "norm_stats.json", STATS)
    _w(r / "norm_stats_image_list.json", [])
    _w(r / "norm_verify.json", {"verdict": "PASS", "checks": {}, "tolerances": {}, "abs_diff": {"mean": 0.0, "std": 0.0},
                                "stored": {k: STATS[k] for k in ("n_pixels", "sum_values", "sum_squares", "mean", "std")}})
    _w(r / "day3_montage_manifest.json", {"png": "results/day3/figures/day3_montage.png", "missing_cases": [],
                                          "cases": [{"file": f"{i}.png", "key": "k", "corner_bg": 0, "gt_px": None} for i in range(6)]})
    _w(r / "pytest_day3.log", GOOD_LOG)
    _w(r / "visual_review.json", {"reviewed": True, "reviewer": "someone", "findings": {"a": "looked fine"}})
    _w(root / "README.md", "# BrainSentinel\n\nStatus: Day 3 in progress\n")
    _w(root / "pyproject.toml", '[project]\nname = "x"\n[tool.pytest.ini_options]\ntestpaths = ["tests"]\n')
    _w(root / "scaffold.sh", "mkdir -p docs/figures\n")
    nb = new_notebook(cells=[new_code_cell("print(1)")])
    (root / "notebooks").mkdir()
    nbformat.write(nb, root / "notebooks" / "a.ipynb")
    _w(root / "configs" / "expected_notebooks.txt", "notebooks/a.ipynb\n")
    return root


def ids(rp):
    return {r["id"] for r in rp["reasons"]}


def test_synth_positive_control_all_evidence_gives_pass(tmp_path):
    rp = rep.build_report(make_good(tmp_path))
    assert rp["verdict"] == "PASS", rp["reasons"]


@pytest.mark.parametrize("log,why", [
    ("", "empty log"),
    ("$ python -m pytest -q\nEXIT_CODE=0\n", "no summary line"),
    ("$ python -m pytest -q\nno tests ran in 0.01s\nEXIT_CODE=5\n", "no tests ran"),
    ("$ python -m pytest -q\n1 failed, 80 passed in 3.20s\nEXIT_CODE=1\n", "failures"),
    ("$ python -m pytest -q\n2 errors in 1.00s\nEXIT_CODE=2\n", "errors only"),
    ("$ python -m pytest -q\n82 passed in 48.60s\n", "no exit code line"),
    ("82 passed in 48.60s\nEXIT_CODE=0\n", "no command line"),
    ("$ python -m pytest -q\n82 passed in 48.60s\nEXIT_CODE=1\n", "summary says passed but exit code 1"),
])
def test_synth_bad_pytest_evidence_is_fail(tmp_path, log, why):
    root = make_good(tmp_path)
    _w(root / "results" / "day3" / "pytest_day3.log", log)
    rp = rep.build_report(root)
    assert rp["verdict"] == "FAIL" and "PYTEST" in ids(rp), why


def test_synth_missing_pytest_log_is_fail(tmp_path):
    root = make_good(tmp_path)
    (root / "results" / "day3" / "pytest_day3.log").unlink()
    assert rep.build_report(root)["verdict"] == "FAIL"


def test_synth_skipped_tests_are_conditional_not_pass(tmp_path):
    root = make_good(tmp_path)
    _w(root / "results" / "day3" / "pytest_day3.log",
       "$ python -m pytest -q\nSKIPPED [1] tests/x.py:3: reason\n81 passed, 1 skipped in 9.00s\nEXIT_CODE=0\n")
    rp = rep.build_report(root)
    assert rp["verdict"] == "CONDITIONAL PASS" and "SKIPPED" in ids(rp)


@pytest.mark.parametrize("name", ["day3_audit.json", "norm_stats.json", "norm_stats_image_list.json",
                                  "norm_verify.json", "day3_montage_manifest.json"])
def test_synth_missing_required_artefact_is_fail(tmp_path, name):
    root = make_good(tmp_path)
    (root / "results" / "day3" / name).unlink()
    rp = rep.build_report(root)
    assert rp["verdict"] == "FAIL" and f"MISSING_{name}" in ids(rp)


def test_synth_hard_audit_problem_is_fail(tmp_path):
    root = make_good(tmp_path)
    p = root / "results" / "day3" / "day3_audit.json"
    d = json.loads(p.read_text())
    d["hard_problems"] = 3
    _w(p, d)
    assert rep.build_report(root)["verdict"] == "FAIL"


def test_synth_verifier_failure_is_fail(tmp_path):
    root = make_good(tmp_path)
    p = root / "results" / "day3" / "norm_verify.json"
    d = json.loads(p.read_text())
    d.update(verdict="FAIL", checks={"file_content_sha256": False})
    _w(p, d)
    assert rep.build_report(root)["verdict"] == "FAIL"


def test_synth_stale_verifier_output_is_fail(tmp_path):
    root = make_good(tmp_path)
    p = root / "results" / "day3" / "norm_verify.json"
    d = json.loads(p.read_text())
    d["stored"]["n_pixels"] = 999
    _w(p, d)
    rp = rep.build_report(root)
    assert rp["verdict"] == "FAIL" and "VERIFY_STALE" in ids(rp)


def test_synth_missing_montage_case_is_fail(tmp_path):
    root = make_good(tmp_path)
    p = root / "results" / "day3" / "day3_montage_manifest.json"
    d = json.loads(p.read_text())
    d["missing_cases"] = ["x"]
    d["cases"] = d["cases"][:5]
    _w(p, d)
    assert rep.build_report(root)["verdict"] == "FAIL"


def test_synth_missing_notebook_is_fail(tmp_path):
    root = make_good(tmp_path)
    (root / "notebooks" / "a.ipynb").unlink()
    rp = rep.build_report(root)
    assert rp["verdict"] == "FAIL" and "NOTEBOOK_MISSING" in ids(rp)


def test_synth_invalid_notebook_is_fail(tmp_path):
    root = make_good(tmp_path)
    (root / "notebooks" / "a.ipynb").write_text("print('python, not json')")
    rp = rep.build_report(root)
    assert rp["verdict"] == "FAIL" and "NOTEBOOK_INVALID" in ids(rp)


def test_synth_empty_notebook_set_is_fail(tmp_path):
    root = make_good(tmp_path)
    (root / "notebooks" / "a.ipynb").unlink()
    (root / "configs" / "expected_notebooks.txt").unlink()
    rp = rep.build_report(root)
    assert rp["verdict"] == "FAIL" and "NO_NOTEBOOKS" in ids(rp)


def test_synth_placeholder_notebook_is_valid_but_distinguished(tmp_path):
    root = make_good(tmp_path)
    nb = new_notebook(cells=[new_markdown_cell("PLACEHOLDER", metadata={"brainsentinel": {"placeholder": True}})])
    nbformat.write(nb, root / "notebooks" / "a.ipynb")
    res = rep.check_notebooks(root)
    assert res["placeholder"] == ["notebooks/a.ipynb"] and not res["valid"] and not res["invalid"]
    assert rep.build_report(root)["verdict"] == "PASS"


@pytest.mark.parametrize("text,expected", [
    ("Status: Day 1\n", "stale"),
    ("Day 3 plan below\nStatus: Day 1 complete\n", "stale"),
    ("Status: Day 3 in progress\n", "ok"),
    ("Day 3 is mentioned here but no status field\n", "no_status_line"),
    ("**Status:** Day 1 complete\n", "stale"),
    ("| Status | Day 1 |\n", "stale"),
    ("## Status\n\nDay 1 complete\n", "stale"),
    ("## Status\n\nDay 3 verified\n", "ok"),
    ("Day 3 appears in prose only. The status of the model is unknown.\n", "no_status_line"),
])
def test_readme_status_detection(tmp_path, text, expected):
    _w(tmp_path / "README.md", text)
    assert rep.readme_status(tmp_path)[0] == expected


def test_synth_stale_readme_blocks_pass(tmp_path):
    root = make_good(tmp_path)
    _w(root / "README.md", "Status: Day 1\n")
    rp = rep.build_report(root)
    assert rp["verdict"] == "CONDITIONAL PASS" and "README_STALE" in ids(rp)


def test_synth_nested_scaffold_blocks_pass(tmp_path):
    root = make_good(tmp_path)
    _w(root / "scaffold.sh", "mkdir -p brainsentinel/src/brainsentinel\n")
    rp = rep.build_report(root)
    assert rp["verdict"] == "CONDITIONAL PASS" and "SCAFFOLD" in ids(rp)


def test_synth_day2_difference_and_pending_visual_review_are_conditional(tmp_path):
    root = make_good(tmp_path)
    p = root / "results" / "day3" / "day3_audit.json"
    d = json.loads(p.read_text())
    d["day2_reproduction"]["test_matches_day2"] = False
    _w(p, d)
    (root / "results" / "day3" / "visual_review.json").unlink()
    rp = rep.build_report(root)
    assert rp["verdict"] == "CONDITIONAL PASS" and {"DAY2_DIFF", "VISUAL_REVIEW_PENDING"} <= ids(rp)
