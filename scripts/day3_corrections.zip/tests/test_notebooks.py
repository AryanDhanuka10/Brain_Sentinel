"""fix_notebooks.py tests on SYNTHETIC notebooks: dry-run safety, backups, no content destroyed, no invented content."""
import importlib.util
import json
from pathlib import Path

import pytest

nbformat = pytest.importorskip("nbformat")
from nbformat.v4 import new_code_cell, new_notebook  # noqa: E402

REPO = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location("fix_notebooks", REPO / "scripts" / "fix_notebooks.py")
fx = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(fx)

PY_TEXT = "# placeholder\nimport torch\nprint('TODO autoencoder')\n"


def test_synth_valid_notebook_untouched_even_with_apply(tmp_path):
    p = tmp_path / "ok.ipynb"
    nbformat.write(new_notebook(cells=[new_code_cell("x = 1")]), p)
    before = p.read_bytes()
    r = fx.process(p, apply=True)
    assert r["status"] == "valid" and not r["modified"] and p.read_bytes() == before


def test_synth_dry_run_never_modifies(tmp_path):
    p = tmp_path / "bad.ipynb"
    p.write_text(PY_TEXT)
    r = fx.process(p, apply=False)
    assert r["status"] == "invalid" and not r["modified"] and p.read_text() == PY_TEXT
    assert not list(tmp_path.glob("*.bak*"))


def test_synth_apply_backs_up_and_preserves_original_text_in_raw_cell(tmp_path):
    p = tmp_path / "bad.ipynb"
    p.write_text(PY_TEXT)
    r = fx.process(p, apply=True)
    assert r["modified"] and Path(r["backup"]).read_text() == PY_TEXT
    nb = nbformat.read(p, as_version=4)
    nbformat.validate(nb)
    raws = [c for c in nb.cells if c.cell_type == "raw"]
    assert raws and raws[0].source == PY_TEXT
    assert nb.cells[0].metadata["brainsentinel"]["placeholder"] is True
    assert not any(c.cell_type == "code" for c in nb.cells)  # nothing pretends to be executable analysis
    assert fx.is_placeholder(nb)


def test_synth_second_backup_does_not_overwrite_first(tmp_path):
    p = tmp_path / "bad.ipynb"
    p.write_text(PY_TEXT)
    fx.process(p, apply=True)
    p.write_text("second broken version")
    r2 = fx.process(p, apply=True)
    assert Path(r2["backup"]).read_text() == "second broken version"
    assert (tmp_path / "bad.ipynb.bak").read_text() == PY_TEXT


def test_synth_empty_file_is_invalid_and_wrapped(tmp_path):
    p = tmp_path / "empty.ipynb"
    p.write_text("")
    assert fx.process(p, apply=False)["status"] == "invalid"
    fx.process(p, apply=True)
    nbformat.validate(nbformat.read(p, as_version=4))


def test_synth_json_with_cells_but_missing_metadata_keeps_all_cells(tmp_path):
    cells = [{"cell_type": "code", "source": ["x = 1\n", "y = 2"], "outputs": [], "execution_count": None, "metadata": {}},
             {"cell_type": "markdown", "source": ["# keep me"], "metadata": {}}]
    p = tmp_path / "partial.ipynb"
    p.write_text(json.dumps({"nbformat": 4, "nbformat_minor": 5, "cells": cells}))
    r = fx.process(p, apply=True)
    assert r["action"] == "repair_keep_cells" and r["modified"]
    nb = nbformat.read(p, as_version=4)
    assert [c.source for c in nb.cells] == ["x = 1\ny = 2", "# keep me"]


def test_synth_find_notebooks_skips_environment_dirs(tmp_path):
    for d in ("brain", ".git", "notebooks"):
        (tmp_path / d).mkdir()
        (tmp_path / d / "a.ipynb").write_text("{}")
    found = [str(p.relative_to(tmp_path)) for p in fx.find_notebooks(tmp_path)]
    assert found == ["notebooks/a.ipynb"]
