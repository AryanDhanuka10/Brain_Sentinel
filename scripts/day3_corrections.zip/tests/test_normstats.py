"""Regression tests for the normalisation fitter and its independent verifier.
ALL tests here use SYNTHETIC images (tests/synth_repo.py). They validate logic, not the BMAD dataset."""
import importlib.util
import json
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

import pathlib

from brainsentinel.data import palette
from brainsentinel.data.checks import load_mask_binary
from brainsentinel.data.normstats import StatsError, fit_train_stats, write_outputs
from brainsentinel.data.palette import MAX_BG

from .synth_repo import CORNERS, PAL, expected_sums, make_repo, rewrite_index, save_png, train_idx

REPO = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location("verify_norm_stats", REPO / "scripts" / "verify_norm_stats.py")
verifier = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(verifier)


def _fit_and_write(repo):
    stats, lst = fit_train_stats(repo)
    write_outputs(repo, stats, lst)
    return stats


def test_synth_uniform_background_matches_independent_numpy(tmp_path):
    info = make_repo(tmp_path, bgs=(0, 0, 0, 0))
    stats = _fit_and_write(tmp_path)
    assert (stats["n_pixels"], stats["sum_values"], stats["sum_squares"]) == expected_sums(info["arrays"])


def test_synth_mixed_nonzero_corner_offsets_exact(tmp_path):
    info = make_repo(tmp_path, bgs=(0, 3, 6, 10))
    stats = _fit_and_write(tmp_path)
    assert (stats["n_pixels"], stats["sum_values"], stats["sum_squares"]) == expected_sums(info["arrays"])
    n, s1, s2 = expected_sums(info["arrays"])
    assert abs(stats["mean"] - s1 / (255 * n)) < 1e-15


def test_synth_corner_above_tolerance_raises(tmp_path):
    make_repo(tmp_path, bgs=(0, 3, 11, 10))
    with pytest.raises(StatsError, match="tolerance|exceeds"):
        fit_train_stats(tmp_path)


def test_synth_differing_corners_raise(tmp_path):
    idx = train_idx(3, 1)
    idx[0, -1] = 4
    make_repo(tmp_path, overrides={1: idx})
    with pytest.raises(StatsError, match="corner"):
        fit_train_stats(tmp_path)


def test_synth_empty_foreground_raises(tmp_path):
    make_repo(tmp_path, overrides={2: np.zeros((240, 240), np.uint8)})
    with pytest.raises(StatsError, match="empty foreground"):
        fit_train_stats(tmp_path)


def test_synth_corrupt_image_raises(tmp_path):
    make_repo(tmp_path, corrupt="00001_60.png")
    with pytest.raises(StatsError):
        fit_train_stats(tmp_path)


def test_synth_missing_training_image_raises(tmp_path):
    info = make_repo(tmp_path)
    (info["brain"] / "train" / "good" / info["names"][0]).unlink()
    with pytest.raises(StatsError, match="expected"):
        fit_train_stats(tmp_path)


def test_synth_index_hash_mismatch_is_hard_failure(tmp_path):
    make_repo(tmp_path)
    rewrite_index(tmp_path, lambda rows: rows[0].update(sha256="0" * 64))
    with pytest.raises(StatsError, match="sha256"):
        fit_train_stats(tmp_path)


def test_synth_missing_index_hash_is_reported_not_ignored(tmp_path):
    make_repo(tmp_path)
    rewrite_index(tmp_path, lambda rows: rows[1].update(sha256=""))
    with pytest.raises(StatsError, match="no sha256"):
        fit_train_stats(tmp_path)
    stats, _ = fit_train_stats(tmp_path, require_index_hashes=False)
    assert stats["index_sha256_status"].startswith("partial: 3/4")


def test_synth_fit_opens_only_train_good(tmp_path, monkeypatch):
    make_repo(tmp_path)
    opened = []
    real_open, real_read = Image.open, pathlib.Path.read_bytes
    monkeypatch.setattr(Image, "open", lambda fp, *a, **k: (opened.append(str(fp)), real_open(fp, *a, **k))[1])
    monkeypatch.setattr(pathlib.Path, "read_bytes", lambda self: (opened.append(str(self)), real_read(self))[1])
    fit_train_stats(tmp_path)
    data = [p for p in opened if "Brain" in p]
    assert data and all("/train/good/" in p for p in data)
    assert not any("/valid/" in p or "/test/" in p for p in opened)


def test_synth_stats_metadata_is_complete(tmp_path):
    make_repo(tmp_path)
    s = _fit_and_write(tmp_path)
    for k in ("split", "group", "n_images", "n_pixels", "mean", "std", "hash_algorithm", "file_content_sha256",
              "image_list_sha256", "git_commit", "python", "numpy", "created_utc", "pixel_rule"):
        assert k in s
    assert s["split"] == "train" and s["group"] == "good" and s["hash_algorithm"] == "sha256"
    assert s["index_sha256_status"] == "verified_all"


def test_synth_verifier_matches_fitter(tmp_path):
    info = make_repo(tmp_path, bgs=(0, 3, 6, 10))
    stats = _fit_and_write(tmp_path)
    res = verifier.verify(tmp_path)
    assert res["verdict"] == "PASS", res["checks"]
    assert res["recomputed"]["sum_values"] == stats["sum_values"] == expected_sums(info["arrays"])[1]


def test_synth_verifier_detects_changed_image_bytes(tmp_path):
    info = make_repo(tmp_path)
    _fit_and_write(tmp_path)
    idx = info["arrays"][info["names"][1]].copy()
    idx[100, 100] = (int(idx[100, 100]) + 1) % 256
    save_png(idx, info["brain"] / "train" / "good" / info["names"][1])
    res = verifier.verify(tmp_path)
    assert res["verdict"] == "FAIL" and not res["checks"]["file_content_sha256"]


def test_synth_verifier_detects_wrong_index_hash(tmp_path):
    make_repo(tmp_path)
    _fit_and_write(tmp_path)
    rewrite_index(tmp_path, lambda rows: rows[2].update(sha256="f" * 64))
    res = verifier.verify(tmp_path)
    assert res["verdict"] == "FAIL" and not res["checks"]["index_hashes_all_present_and_equal"]


def test_synth_verifier_detects_missing_training_image(tmp_path):
    info = make_repo(tmp_path)
    _fit_and_write(tmp_path)
    (info["brain"] / "train" / "good" / info["names"][3]).unlink()
    res = verifier.verify(tmp_path)
    assert res["verdict"] == "FAIL" and not res["checks"]["n_images_equals_disk_and_expected"]


def test_synth_verifier_detects_valid_test_contamination(tmp_path):
    make_repo(tmp_path)
    _fit_and_write(tmp_path)
    lp = tmp_path / "results" / "day3" / "norm_stats_image_list.json"
    lst = json.loads(lp.read_text())
    lst.append({"path": "valid/good/img/10000_60.png", "sha256": "0" * 64})
    lp.write_text(json.dumps(lst))
    res = verifier.verify(tmp_path)
    assert res["verdict"] == "FAIL" and not res["checks"]["image_list_only_train_good"]


def test_synth_verifier_disagreement_fails_loudly(tmp_path):
    make_repo(tmp_path)
    stats = _fit_and_write(tmp_path)
    for field, bump in (("n_pixels", 1), ("sum_values", 1), ("sum_squares", 1)):
        bad = dict(stats, **{field: stats[field] + bump})
        (tmp_path / "data" / "processed" / "norm_stats.json").write_text(json.dumps(bad))
        assert verifier.verify(tmp_path)["verdict"] == "FAIL", field
    bad = dict(stats, mean=stats["mean"] + 1e-9)  # above the 1e-12 tolerance
    (tmp_path / "data" / "processed" / "norm_stats.json").write_text(json.dumps(bad))
    assert verifier.verify(tmp_path)["verdict"] == "FAIL"


def test_synth_verifier_rejects_image_the_fitter_would_reject(tmp_path):
    """Same pixel rule: differing corners must fail in the verifier too (the old verifier used idx[0,0] only)."""
    info = make_repo(tmp_path)
    _fit_and_write(tmp_path)
    idx = info["arrays"][info["names"][1]].copy()
    idx[-1, -1] = 9
    save_png(idx, info["brain"] / "train" / "good" / info["names"][1])
    res = verifier.verify(tmp_path)
    assert res["verdict"] == "FAIL" and any("corner pixels differ" in p for p in res["problems"])


def test_verifier_and_palette_bg_tolerance_agree():
    assert verifier.MAX_BG == MAX_BG == palette.MAX_BG == 10


def test_synth_background_correction_handles_nonzero_offsets(tmp_path):
    from brainsentinel.data.palette import Palette
    from brainsentinel.data.preprocessing import load_index_image
    pal = Palette.from_keys(((PAL[:, 0].astype(np.uint32) << 16) | (PAL[:, 1].astype(np.uint32) << 8) | PAL[:, 2]))
    for bg in (0, 1, 6, 10):
        idx = train_idx(bg, 1)
        save_png(idx, tmp_path / "x.png")
        out, brain, got_bg = load_index_image(tmp_path / "x.png", pal)
        assert got_bg == bg and out.dtype == np.uint8
        assert all(out[r, c] == 0 for r, c in CORNERS)
        assert np.array_equal(brain, idx > bg) and np.array_equal(out > 0, brain)
        assert np.array_equal(out[brain], idx[brain] - bg)


def test_synth_small_lesion_masks_preserved(tmp_path):
    colours = [(56, 55, 77), (112, 123, 143), (255, 255, 255)]
    for n in (1, 2, 7, 99):
        m = np.zeros((240, 240, 4), np.uint8)
        m[..., 3] = 255
        for i in range(n):
            m[100, 50 + i, :3] = colours[i % 3]
        Image.fromarray(m, "RGBA").save(tmp_path / "m.png")
        b = load_mask_binary(tmp_path / "m.png")
        assert b.shape == (240, 240) and int(b.sum()) == n and set(np.unique(b).tolist()) <= {0, 1}
